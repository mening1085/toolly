<template>
  <div class="max-w-lg mx-auto py-8">
    <h1 class="text-2xl font-bold mb-4">🎁 คำนวณหารเงินของขวัญ/ของใช้</h1>
    <p class="mb-4">แบ่งเงินซื้อของขวัญรวมกัน</p>
    <!-- TODO: implement tool -->
  </div>
</template>
