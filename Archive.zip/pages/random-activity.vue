<template>
  <div class="max-w-lg mx-auto py-8">
    <h1 class="text-2xl font-bold mb-4">💡 สุ่มไอเดียกิจกรรมวันหยุด</h1>
    <p class="mb-4">ไม่รู้จะทำอะไรดี? ให้ AI แนะนำ</p>
    <!-- TODO: implement tool -->
  </div>
</template>
<script setup>
// TODO: implement tool
</script>
