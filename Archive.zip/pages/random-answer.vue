<template>
  <div class="max-w-lg mx-auto py-8">
    <h1 class="text-2xl font-bold mb-4">🎲 สุ่มคำตอบ (ใช่/ไม่ใช่)</h1>
    <p class="mb-4">
      เครื่องมือให้คำตอบแบบสุ่ม (เช่น ใช่/ไม่ใช่, ไป/ไม่ไป) – ตลก ๆ
      สำหรับคนลังเล
    </p>
    <!-- TODO: implement tool -->
  </div>
</template>
<script setup>
// TODO: implement tool
</script>
