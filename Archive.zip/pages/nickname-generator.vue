<template>
  <div class="max-w-lg mx-auto py-8">
    <h1 class="text-2xl font-bold mb-4">🐶 ตั้งชื่อเล่น/สัตว์เลี้ยง</h1>
    <p class="mb-4">ตัวช่วยตั้งชื่อเล่น/สัตว์เลี้ยง</p>
    <!-- TODO: implement tool -->
  </div>
</template>
<script setup>
// TODO: implement tool
</script>
