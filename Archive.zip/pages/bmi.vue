<template>
  <div class="max-w-lg mx-auto py-8">
    <h1 class="text-2xl font-bold mb-4">⚖️ คำนวณ BMI / น้ำหนักในอุดมคติ</h1>
    <p class="mb-4">เครื่องคำนวณ BMI / น้ำหนักในอุดมคติ – ใช้งานง่าย</p>
    <!-- TODO: implement tool -->
  </div>
</template>
<script setup>
// TODO: implement tool
</script>
