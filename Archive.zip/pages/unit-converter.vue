<template>
  <div class="max-w-lg mx-auto py-8">
    <h1 class="text-2xl font-bold mb-4">📏 ตัวแปลงหน่วย</h1>
    <p class="mb-4">ตัวแปลงหน่วย (เช่น เซนติเมตรเป็นนิ้ว)</p>
    <!-- TODO: implement tool -->
  </div>
</template>
<script setup>
// TODO: implement tool
</script>
