<template>
  <div class="max-w-lg mx-auto py-8">
    <h1 class="text-2xl font-bold mb-4">💧 เตือนดื่มน้ำ</h1>
    <p class="mb-4">
      เครื่องมือเตือนดื่มน้ำ – ตั้งเวลาง่าย ๆ ให้เตือนทุก 2 ชม.
    </p>
    <!-- TODO: implement tool -->
  </div>
</template>
<script setup>
// TODO: implement tool
</script>
