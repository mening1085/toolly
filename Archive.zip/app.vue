<template>
  <NuxtLayout>
    <NuxtPwaManifest />
    <NuxtPage />
  </NuxtLayout>
</template>

<script setup>
// ยังไม่มี component จริง จะสร้าง Navbar/Footer ใน components ภายหลัง
</script>
