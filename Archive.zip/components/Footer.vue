<template>
  <footer
    class="w-full bg-white/80 dark:bg-gray-800/80 text-center text-xs py-4 text-gray-500 border-t border-gray-200 dark:border-gray-700"
  >
    <div>© 2024 toolly.xmmeenn.com | Made with ❤️ for daily life tools.</div>
    <div class="mt-1">
      <a
        href="https://github.com/xmmeenn/toolly"
        target="_blank"
        class="underline hover:text-blue-600"
        >GitHub</a
      >
    </div>
  </footer>
</template>

<script setup>
// ยังไม่ต้องมี logic
</script>
